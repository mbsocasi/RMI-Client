import java.rmi.Naming;

public class ClientRMI {
    public static void main(String[] args) {
        try {
            // Localizar el servicio RMI registrado con el nombre "HelloService"
            IHelloService helloService = (IHelloService) Naming.lookup("rmi://10.40.46.222/Hello");

            String response = helloService.sayHello("Moises");
            System.out.println("Response Service: => " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}